from turtle import Screen, Turtle
from time import *

#Tarif screen baraye turtle
screen = Screen()
screen.bgcolor("black")
screen.setup(width=800, height=800)

#Emtiyazi(Function taghyire ax)
screen.bgpic("07.gif")
counter=0
def change_bg():
    global counter
    bg_list=["01.gif","02.gif","03.gif","04.gif","05.gif","06.gif","07.gif"]
    screen.bgpic(bg_list[counter])
    counter+=1
    if counter>=len(bg_list):
        counter=0

#Tarif turtle va function rasme safheye saat
clock_pen = Turtle()
def clockFace():
    # Rasme dayere
    clock_pen.pen(shown=False, pencolor="#FFF2CC", pensize=5)
    clock_pen.penup()
    clock_pen.setheading(0)
    clock_pen.setposition(0, 250)
    clock_pen.pendown()
    clock_pen.circle(-250)
    clock_pen.penup()
    clock_pen.setheading(60)


roman_numbers = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII']
for i in range(12):
    clock_pen.setposition(0,-19)
    clock_pen.fd(185)
    clock_pen.write(roman_numbers[i], align='center', font=('Bahnschrift Condensed', 25, 'bold'))
    clock_pen.rt(30)
clock_pen.setheading(90)
